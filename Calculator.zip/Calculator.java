/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package calculator.java ;

import java.util.Scanner;

public class Calculator {
  

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter First Number:");
        double x=in.nextInt();
        System.out.println("Enter Second Number :");
        double y=in.nextInt();
        
        double sum=x+y;
        double subtract=x-y;
        double product=x*y;
        double div=x/y;
        System.out.println("sum result:" +sum );
        System.out.println("subtract result:"+subtract);
        System.out.println("product result:"+product);
        System.out.println("div result:"+div);
    }
}
